<div class="phone-contact">
            <a href="tel:0345883555"><i class="fas fa-phone-alt faa-ring animated fa-5x"></i></a>
        </div>
        <span onclick="topFunction()" id="back-to-top">
            <i class="fas fa-arrow-up"></i>
        </span>
        <header>
            
            <div class="header-top">
                <div class="container">
                    <div class="header-contact">
                        <span>
                            <i class="fas fa-user"></i>
                            <p>Hotline:</p>
                            <a href="tel:0345883555" style="color: #fff;">0345883555</a>
                        </span>
                    </div>
                    <div class="header-login">
                        <a href="login.html">Đăng nhập / Đăng kí</a>
                    </div>
                </div>

                <nav>
                    <div class="container">
                        <div class="logo">
                            <a href="index.html"><img src="/img/vin.png" alt=""></a>
                        </div>
                        <div class="nav-items">
                            <li><a class="nav-link active1" href="index.php">Trang chủ</a></li>
                            <li><a class="nav-link" href="tracking.php">Tra đơn hàng</a></li>
                            <li><a class="nav-link" href="sevice.php">Dịch vụ</a></li>
                            <li><a class="nav-link" href="contact.php">Liên hệ chúng tôi</a></li>
                        </div>
                        <div class="menu-icon">
                            <i class="fas fa-bars"></i>
                        </div>
                    </div>
                </nav>
            </div>
        </header>